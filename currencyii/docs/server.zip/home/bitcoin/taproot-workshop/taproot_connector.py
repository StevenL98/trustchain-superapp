import util
from test_framework.messages import CTransaction

CTransaction()
tx.deserialize(BytesIO(bytes.fromhex(tx_hex)))
tx.rehash()

 
